#ifndef GBILEFLOW_H
#define GBILEFLOW_H

#include "model.h"
#include <QMainWindow>
#include <QTableWidget>
#include <QPushButton>

namespace Ui {
class Gbileflow;
}

class Gbileflow : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gbileflow(QWidget *parent = nullptr);
    void calculate(QTableWidget*);
    ~Gbileflow();

private slots:
    void get_started();

private:
    Ui::Gbileflow *ui;
    QTableWidget* qT_debuger;
    QPushButton* qpb_start;
};

#endif // GBILEFLOW_H

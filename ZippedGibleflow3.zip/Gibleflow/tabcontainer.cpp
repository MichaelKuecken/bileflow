#include "tabcontainer.h"

Tabcontainer::Tabcontainer(QString filename, QWidget* parent)
{
    _filename = filename;
    qtw_table = new QTableWidget();
    qtw_table->setGeometry(500, 25, 450, 450);
    qtw_table->setParent(parent);
    qgv_chart = new QGraphicsView();
    qgv_chart->setGeometry(25,25,450,450);
    qgv_chart->setParent(parent);
    qgv_chart->show();
    qtw_table->show();
}

QString Tabcontainer::get_file()
{
    return _filename;
}

QTableWidget* Tabcontainer::get_table()
{
    return  qtw_table;
}

#ifndef TABCONTAINER_H
#define TABCONTAINER_H

#include <QFile>
#include <QtWidgets>
#include <QPainterPath>

class Tabcontainer
{
public:
    Tabcontainer(QString, QWidget*);

    QString get_file();

    QTableWidget* get_table();

private:
    QString _filename;
    QTableWidget* qtw_table;
    QGraphicsView* qgv_chart;
};

#endif // TABCONTAINER_H

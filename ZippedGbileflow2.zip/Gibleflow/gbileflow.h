#ifndef GBILEFLOW_H
#define GBILEFLOW_H

#include "model.h"
#include "tabcontainer.h"
#include <QMainWindow>
#include <QTableWidget>
#include <QPushButton>
#include <QtWidgets>
#include <QList>

namespace Ui {
class Gbileflow;
}

class Gbileflow : public QMainWindow
{
    Q_OBJECT

public:
    explicit Gbileflow(QWidget *parent = nullptr);
    void calculate(QTableWidget*, QString);
    ~Gbileflow();

private slots:
    void get_started();
    void open();

private:
    Ui::Gbileflow *ui;
    QTabWidget* qtw_main;
    QAction *openAction;
    QAction *saveAction;
    QAction *exitAction;
    QAction *cTabAction;
    QAction *startAction;
    QMenu *fileMenu;
    QList<Tabcontainer*> tlist;
};

#endif // GBILEFLOW_H

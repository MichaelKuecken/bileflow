#include "gbileflow.h"
#include "ui_gbileflow.h"
using namespace std;

Gbileflow::Gbileflow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Gbileflow)
{
    ui->setupUi(this);
    qtw_main = new QTabWidget();
    openAction = new QAction(tr("&Open"), this);
    saveAction = new QAction(tr("&Save"), this);
    exitAction = new QAction(tr("E&xit"), this);
    startAction = new QAction(tr("&Start"), this);
    cTabAction = new QAction(tr("&Close Tab"), this);
    qtw_main->setParent(this);
    qtw_main->setGeometry(0, 50, 1000, 550);
    qtw_main->show();

    connect(openAction, SIGNAL(triggered()), this, SLOT(open()));
    connect(saveAction, SIGNAL(triggered()), this, SLOT(save()));
    connect(exitAction, SIGNAL(triggered()), qApp, SLOT(quit()));
    connect(cTabAction, SIGNAL(triggered()), this, SLOT(close_tab()));
    connect(startAction, SIGNAL(triggered()), this, SLOT(get_started()));

    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(openAction);
    fileMenu->addAction(saveAction);
    fileMenu->addAction(cTabAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);
    fileMenu->addAction(startAction);

}

void Gbileflow::calculate(QTableWidget* qtw, QString filename)
{
    const string workdir = "/home/cedric/Documents/Qt_Testfiles/";
    const string identifier = "6724";

    const string inputfile = workdir + "input_" + identifier + ".dat";
    const string outputfile =  workdir + "output_" + identifier + ".dat";

    Model model(filename.toStdString());

    double pout = model.shooting();

    model.single_run(pout, true);

    //string filename = "/home/michael/bileflow/real_values/output.dat";

    model.printout_results(qtw);

}

void  Gbileflow::get_started()
{
    calculate(tlist[qtw_main->currentIndex()]->get_table() ,tlist[qtw_main->currentIndex()]->get_file());
}

void Gbileflow::open()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"), "",
    tr("Text Files (*.dat)"));
    QString tmp = "";
    for(auto& sign : fileName)
    {
        if(sign == '/')
        {
            tmp = "";
        }else{
            tmp += sign;
        }
    }
    if (tmp != "") {
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly)) {
            QMessageBox::critical(this, tr("Error"), tr("Could not open file"));
            return;
        }
        qtw_main->setCurrentIndex(qtw_main->addTab(new QWidget(), tmp));
        Tabcontainer* tabcon = new Tabcontainer(fileName, qtw_main->currentWidget());
        tlist.push_back(tabcon);
    }
}


Gbileflow::~Gbileflow()
{
    delete ui;
}

#include "tabcontainer.h"

Tabcontainer::Tabcontainer(QString filename, QWidget* parent)
{
    _filename = filename;
    qtw_table = new QTableWidget();
    qtw_table->setGeometry(500, 25, 450, 450);
    qtw_table->setParent(parent);
    qtw_table->show();
}

QString Tabcontainer::get_file()
{
    return _filename;
}

QTableWidget* Tabcontainer::get_table()
{
    return  qtw_table;
}

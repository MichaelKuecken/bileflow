#ifndef TABCONTAINER_H
#define TABCONTAINER_H

#include <QFile>
#include <QtWidgets>

class Tabcontainer
{
public:
    Tabcontainer(QString, QWidget*);

    QString get_file();

    QTableWidget* get_table();

private:
    QString _filename;
    QTableWidget* qtw_table;
};

#endif // TABCONTAINER_H
